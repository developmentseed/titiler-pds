"""rio-tiler-pds.landsat.aws"""

from rio_tiler_pds.landsat.aws.landsat8 import L8Reader  # noqa
from rio_tiler_pds.landsat.aws.landsat_collection2 import LandsatC2Reader  # noqa
