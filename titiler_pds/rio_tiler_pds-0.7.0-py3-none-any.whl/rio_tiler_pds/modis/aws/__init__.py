"""rio-tiler-pds.modis.aws"""

# fmt: off
from rio_tiler_pds.modis.aws.modis_astraea import MODISReader as MODISASTRAEAReader # noqa isort:skip
# fmt: on
from rio_tiler_pds.modis.aws.modis_pds import MODISReader as MODISPDSReader  # noqa
