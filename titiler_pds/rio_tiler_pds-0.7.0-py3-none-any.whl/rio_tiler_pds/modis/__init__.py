"""rio-tiler-pds.modis"""

from rio_tiler_pds.modis import aws  # noqa
from rio_tiler_pds.modis.utils import sceneid_parser  # noqa
